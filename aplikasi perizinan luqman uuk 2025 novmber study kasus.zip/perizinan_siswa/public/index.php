<?php
// Development: show errors for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../app/controllers/AuthController.php';
require_once __DIR__ . '/../app/controllers/IzinController.php';

$action = $_GET['action'] ?? 'login';
$id = $_GET['id'] ?? null;

// Allow short action names used in views and map to controller actions
$aliases = [
    'create' => 'create_izin',
    'edit'   => 'edit_izin',
    'delete' => 'delete_izin',
    'list'   => 'list_izin',
];
if (isset($aliases[$action])) {
    $action = $aliases[$action];
}

$auth = new AuthController();
$izin = new IzinController();

switch($action){
    case 'login': $auth->login(); break;
    case 'logout': $auth->logout(); break;
    case 'register': $auth->register(); break;
    case 'list_izin': $izin->list(); break;
    case 'create_izin': $izin->create(); break;
    case 'edit_izin': $izin->edit($id); break;
    case 'delete_izin': $izin->delete($id); break;
    default: echo "Page not found"; break;
}
