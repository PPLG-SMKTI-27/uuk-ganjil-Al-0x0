<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../models/User.php';

class AuthController {
    private $userModel;
    public function __construct() {
        $db = (new Database())->getConnection();
        $this->userModel = new User($db);
    }

    public function login() {
        session_start();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'];
            $password = $_POST['password'];
            $role     = $_POST['role'];

            $user = $this->userModel->login($username, $password, $role);
            if ($user) {
                $_SESSION['user'] = $user;
                header("Location: index.php?action=list_izin");
                exit;
            } else {
                $error = "Login gagal! Username, password, atau role salah.";
            }
        }
        require_once __DIR__ . '/../views/login.php';
    }

    public function register() {
        session_start();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim($_POST['username']);
            $password = $_POST['password'];
            $role     = $_POST['role'];
            $nama     = $_POST['nama'] ?? null;

            if (empty($username) || empty($password) || empty($role)) {
                $error = "Semua field wajib diisi.";
                require_once __DIR__ . '/../views/register.php';
                return;
            }

            $created = $this->userModel->create($username, $password, $role, $nama);
            if ($created) {
                header("Location: index.php?action=login");
                exit;
            } else {
                $error = "Gagal mendaftar. Username mungkin sudah dipakai.";
            }
        }

        require_once __DIR__ . '/../views/register.php';
    }

    public function logout() {
        session_start();
        session_destroy();
        header("Location: index.php?action=login");
        exit;
    }
}
