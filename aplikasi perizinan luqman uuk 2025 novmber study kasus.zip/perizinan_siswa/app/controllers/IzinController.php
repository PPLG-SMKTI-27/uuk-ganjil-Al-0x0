<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../models/Izin.php';
require_once __DIR__ . '/../models/User.php';

class IzinController {
    private $db;
    private $izinModel;
    private $userModel;

    public function __construct() {
        $this->db = (new Database())->getConnection();
        $this->izinModel = new Izin($this->db);
        $this->userModel = new User($this->db);
    }

    public function list(){
        session_start();
        $data = $this->izinModel->getAll();
        // surface any session messages to the view then clear them
        $error = $_SESSION['error'] ?? null; unset($_SESSION['error']);
        $success = $_SESSION['success'] ?? null; unset($_SESSION['success']);
        // expose userModel to view for name lookups
        $userModel = $this->userModel;
        require_once __DIR__ . '/../views/izin/index.php';
    }

    public function create(){
        session_start();

        // Only allow siswa to create izin
        $role = strtolower(trim($_SESSION['user']['role'] ?? ''));
        if ($role !== 'siswa') {
            $_SESSION['error'] = 'Akses ditolak: hanya siswa yang dapat membuat izin.';
            header("Location: index.php?action=list_izin");
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $siswaNama = trim($_POST['siswa_nama'] ?? '');
            $waliNama  = trim($_POST['wali_nama'] ?? '');
            $alasan    = trim($_POST['alasan'] ?? '');
            $tanggal   = $_POST['tanggal'] ?? null;

            if ($siswaNama === '' || $waliNama === '' || $alasan === '' || !$tanggal) {
                $error = 'Semua field wajib diisi.';
                require_once __DIR__ . '/../views/izin/create.php';
                return;
            }

            $siswaId = $this->userModel->getOrCreate($siswaNama, 'siswa');
            $waliId  = $this->userModel->getOrCreate($waliNama, 'walikelas');

            if (!$siswaId || !$waliId) {
                $error = 'Gagal membuat user siswa/wali. Periksa kembali input.';
                require_once __DIR__ . '/../views/izin/create.php';
                return;
            }

            $jam = trim($_POST['jam'] ?? '') ?: null;
            $created = $this->izinModel->create(
                $siswaId,
                $waliId,
                $alasan,
                $tanggal,
                $jam
            );

            if ($created) {
                header("Location: index.php?action=list_izin");
                exit;
            } else {
                $dbErr = $this->izinModel->getLastError();
                $error = 'Gagal membuat izin. Terjadi kesalahan pada database.' . ($dbErr ? ' Detail: '.htmlspecialchars($dbErr) : '');
                require_once __DIR__ . '/../views/izin/create.php';
                return;
            }
        }

        require_once __DIR__ . '/../views/izin/create.php';
    }

    public function edit($id){
        session_start();
        // Only admin can edit
        $role = strtolower(trim($_SESSION['user']['role'] ?? ''));
        if ($role !== 'admin') {
            $_SESSION['error'] = 'Akses ditolak: hanya admin yang dapat mengedit izin.';
            header("Location: index.php?action=list_izin");
            exit;
        }

        $izin = $this->izinModel->getById($id);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $alasan = trim($_POST['alasan'] ?? '');
            $tanggal = $_POST['tanggal'] ?? null;
            $jam = trim($_POST['jam'] ?? '') ?: null;

            $updated = $this->izinModel->update($id, $alasan, $tanggal, $jam);
            if ($updated) {
                $_SESSION['success'] = 'Izin berhasil diperbarui.';
            } else {
                $_SESSION['error'] = 'Gagal memperbarui izin.' . ($this->izinModel->getLastError() ? ' Detail: '.htmlspecialchars($this->izinModel->getLastError()) : '');
            }
            header("Location: index.php?action=list_izin");
            exit;
        }

        // expose user data to view
        $userModel = $this->userModel;
        $siswaUser = $this->userModel->getById($izin['siswa_id'] ?? 0);
        $waliUser = $this->userModel->getById($izin['wali_kelas_id'] ?? 0);

        require_once __DIR__ . '/../views/izin/edit.php';
    }

    public function delete($id){
        session_start();
        $role = strtolower(trim($_SESSION['user']['role'] ?? ''));
        if (!in_array($role, ['walikelas','wali_kelas','wali-kelas'])) {
            $_SESSION['error'] = 'Akses ditolak: hanya Wali Kelas yang boleh menghapus.';
            header("Location: index.php?action=list_izin");
            exit;
        }

        $this->izinModel->delete($id);
        $_SESSION['success'] = 'Izin berhasil dihapus.';
        header("Location: index.php?action=list_izin");
        exit;
    }
}
