<?php require_once __DIR__ . '/layout/header.php'; ?>

<div style="max-width:420px;margin:30px auto;background:#fff;padding:24px;border-radius:8px;box-shadow:0 6px 20px rgba(0,0,0,0.08);">
    <h2 style="text-align:center;margin-top:0;">Login Sistem Perizinan</h2>
    <?php if(!empty($error)): ?>
        <div style="color:#e74c3c;text-align:center;margin-bottom:12px"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post" action="index.php?action=login">
        <label>Username</label>
        <input type="text" name="username" placeholder="Username" required>
        <label>Password</label>
        <input type="password" name="password" placeholder="Password" required>
        <label>Role</label>
        <select name="role" required>
            <option value="">-- Pilih Role --</option>
            <option value="admin">Admin</option>
            <option value="walikelas">Wali Kelas</option>
            <option value="siswa">Siswa</option>
        </select>
        <button type="submit" style="margin-top:8px;">Login</button>
    </form>
    <p style="text-align:center;margin-top:12px">Belum punya akun? <a href="index.php?action=register">Daftar</a></p>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>
