<?php require_once __DIR__ . '/../layout/header.php'; ?>

<h2 style="text-align:center;">Edit Izin</h2>
<?php if (!empty($error)): ?>
    <div style="color:red; margin-bottom:8px; text-align:center"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if (empty($izin)): ?>
    <div style="text-align:center;color:red">Izin tidak ditemukan.</div>
<?php else: ?>
    <form method="post" style="max-width:720px;margin:8px auto;">
        <div>
            <label>Nama Siswa</label>
            <input type="text" disabled value="<?= htmlspecialchars($siswaUser['nama'] ?? 'N/A') ?>">
        </div>
        <div>
            <label>Nama Wali Kelas</label>
            <input type="text" disabled value="<?= htmlspecialchars($waliUser['nama'] ?? 'N/A') ?>">
        </div>

        <label>Alasan</label>
        <textarea name="alasan" required style="min-height:100px"><?= htmlspecialchars($_POST['alasan'] ?? $izin['alasan'] ?? '') ?></textarea>

        <label>Tanggal</label>
        <input type="date" name="tanggal" required value="<?= htmlspecialchars($_POST['tanggal'] ?? $izin['tanggal'] ?? '') ?>">

        <label>Jam Izin</label>
        <input type="time" name="jam" value="<?= htmlspecialchars($_POST['jam'] ?? $izin['jam'] ?? '') ?>">

        <div style="text-align:right;margin-top:10px"><button type="submit">Simpan Perubahan</button></div>
    </form>
<?php endif; ?>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>