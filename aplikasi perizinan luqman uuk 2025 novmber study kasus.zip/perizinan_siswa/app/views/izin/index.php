<?php require_once __DIR__ . '/../layout/header.php'; ?>

<?php if (!empty($error)): ?>
    <div style="color:#e74c3c;text-align:center;margin-bottom:8px"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>
<?php if (!empty($success)): ?>
    <div style="color:#2ecc71;text-align:center;margin-bottom:8px"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<h2 style="text-align:center; margin-top:6px">Daftar Izin Siswa</h2>
<?php $viewerRole = strtolower(trim($_SESSION['user']['role'] ?? '')); ?>
<div style="text-align:center; margin:14px 0 18px;">
    <?php if ($viewerRole === 'siswa'): ?>
        <a href="index.php?action=create" class="button">Buat Izin Baru</a>
    <?php endif; ?>
</div>

<div style="overflow:auto">
    <table>
        <tr>
            <th>ID</th>
            <th>Siswa</th>
            <th>Wali Kelas</th>
            <th>Alasan</th>
            <th>Tanggal</th>
            <th>Jam Izin</th>
            <th>Aksi</th>
        </tr>
        <?php $currentRole = strtolower(trim($_SESSION['user']['role'] ?? '')); $currentUserId = $_SESSION['user']['id'] ?? null; ?>
        <?php foreach($data as $izin): ?>
        <tr>
            <td><?= $izin['id'] ?></td>
            <td><?php $siswa = $userModel->getById($izin['siswa_id']); ?><?= htmlspecialchars($siswa['nama'] ?? $izin['siswa_id']) ?></td>
            <td><?php $wali = $userModel->getById($izin['wali_kelas_id']); ?><?= htmlspecialchars($wali['nama'] ?? $izin['wali_kelas_id']) ?></td>
            <td><?= htmlspecialchars($izin['alasan']) ?></td>
            <td><?= htmlspecialchars($izin['tanggal']) ?></td>
            <td><?= htmlspecialchars($izin['jam'] ?? '') ?></td>
                <td>
                    <?php if ($currentRole === 'admin'): ?>
                        <a href="index.php?action=edit&id=<?= $izin['id'] ?>" class="button">Edit</a>
                    <?php endif; ?>
                    <?php if (in_array($viewerRole, ['walikelas','wali_kelas','wali-kelas'])): ?>
                        <a href="javascript:void(0)" onclick="confirmDelete('index.php?action=delete&id=<?= $izin['id'] ?>')" class="button">Hapus</a>
                    <?php endif; ?>
                </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>
