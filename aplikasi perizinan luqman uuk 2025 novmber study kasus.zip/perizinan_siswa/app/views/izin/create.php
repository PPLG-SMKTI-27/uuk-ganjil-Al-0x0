<?php require_once __DIR__ . '/../layout/header.php'; ?>

<h2 style="text-align:center;">Buat Izin Baru</h2>
<?php if (!empty($error)): ?>
    <div style="color:red; margin-bottom:8px; text-align:center"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="post" style="max-width:720px;margin:8px auto;">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <div>
            <label>Nama Siswa</label>
            <input type="text" name="siswa_nama" required value="<?= htmlspecialchars($_POST['siswa_nama'] ?? '') ?>">
        </div>
        <div>
            <label>Nama Wali Kelas</label>
            <input type="text" name="wali_nama" required value="<?= htmlspecialchars($_POST['wali_nama'] ?? '') ?>">
        </div>
    </div>

    <label>Alasan</label>
    <textarea name="alasan" required style="min-height:100px"><?= htmlspecialchars($_POST['alasan'] ?? '') ?></textarea>

    <label>Tanggal</label>
    <input type="date" name="tanggal" required value="<?= htmlspecialchars($_POST['tanggal'] ?? '') ?>">
    
    <label>Jam Izin</label>
    <input type="time" name="jam" value="<?= htmlspecialchars($_POST['jam'] ?? '') ?>">

    <div style="text-align:right;margin-top:10px"><button type="submit">Kirim Izin</button></div>
</form>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>
