<?php require_once __DIR__ . '/layout/header.php'; ?>

<div style="max-width:520px;margin:30px auto;background:#fff;padding:24px;border-radius:8px;box-shadow:0 6px 20px rgba(0,0,0,0.06);">
    <h2 style="text-align:center;margin-top:0;">Daftar Akun</h2>
    <?php if(!empty($error)): ?>
        <div style="color:#e74c3c;text-align:center;margin-bottom:12px"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post" action="index.php?action=register">
        <label>Username</label>
        <input type="text" name="username" placeholder="Username" required value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
        <label>Password</label>
        <input type="password" name="password" placeholder="Password" required>
        <label>Nama (opsional)</label>
        <input type="text" name="nama" placeholder="Nama" value="<?= htmlspecialchars($_POST['nama'] ?? '') ?>">
        <label>Role</label>
        <select name="role" required>
            <option value="">-- Pilih Role --</option>
            <option value="siswa">Siswa</option>
            <option value="walikelas">Wali Kelas</option>
            <option value="admin">Admin</option>
        </select>
        <button type="submit" style="margin-top:8px;">Daftar</button>
    </form>
    <p style="text-align:center;margin-top:12px">Sudah punya akun? <a href="index.php?action=login">Login</a></p>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>
