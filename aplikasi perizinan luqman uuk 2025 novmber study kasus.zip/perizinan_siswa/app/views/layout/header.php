<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistem Perizinan Siswa</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Small overrides for header/nav */
        .container { max-width:1100px; margin:0 auto; padding:0 16px; }
        header.site-header { background: linear-gradient(90deg,#2ecc71,#27ae60); color:#fff; padding:14px 0; }
        .nav { display:flex; justify-content:space-between; align-items:center; gap:12px; }
        .nav-left { display:flex; gap:12px; align-items:center; }
        .brand { font-weight:700; font-size:20px; }
        nav a { color:#fff; text-decoration:none; margin-left:8px; }
        .user-info { color:#fff; font-size:14px; }
        .top-actions a.logout { background:transparent; border:1px solid rgba(255,255,255,0.3); padding:6px 10px; border-radius:4px; }
    </style>
    <script>
        function confirmDelete(url) {
            if(confirm('Apakah Anda yakin ingin menghapus data ini?')) {
                window.location.href = url;
            }
        }
    </script>
</head>
<body>
<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<header class="site-header">
    <div class="container nav">
        <div class="nav-left">
            <div class="brand">Sistem Perizinan</div>
            <nav>
                <a href="index.php?action=list">Daftar Izin</a>
                <a href="index.php?action=create">Buat Izin</a>
            </nav>
        </div>
        <div class="top-actions">
            <?php if(!empty($_SESSION['user'])): ?>
                <span class="user-info">Halo, <?= htmlspecialchars($_SESSION['user']['nama'] ?? $_SESSION['user']['username']) ?></span>
                <a href="index.php?action=logout" class="logout">Logout</a>
            <?php else: ?>
                <a href="index.php?action=login">Login</a>
                <a href="index.php?action=register">Daftar</a>
            <?php endif; ?>
        </div>
    </div>
</header>
<main class="container" style="padding:20px 0 60px;">
