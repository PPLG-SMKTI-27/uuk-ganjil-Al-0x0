    </main>
    <footer style="text-align:center; padding:18px 0; background:#f1f5f4; margin-top:30px; border-top:1px solid #e6e6e6;">
        <div class="container">&copy; <?= date('D') ?>,Jika izin anda hilang maka izin telah ditolak oleh wali kelas :P</div>
    </footer>
</body>
</html>
