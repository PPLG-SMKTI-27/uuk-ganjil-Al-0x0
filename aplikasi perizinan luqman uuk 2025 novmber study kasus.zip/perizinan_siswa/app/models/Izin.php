<?php
class Izin {
    private $conn;
    private $table = "izin";
    private $lastError = null;

    public function __construct($db){
        $this->conn = $db;
    }

    public function getAll(){
        $stmt = $this->conn->query("SELECT * FROM izin");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function create($siswa_id, $wali_id, $alasan, $tanggal, $jam = null){
        try {
            $stmt = $this->conn->prepare("INSERT INTO izin (siswa_id, wali_kelas_id, alasan, tanggal, jam) VALUES (:siswa, :wali, :alasan, :tanggal, :jam)");
            $stmt->bindParam(":siswa", $siswa_id, PDO::PARAM_INT);
            $stmt->bindParam(":wali", $wali_id, PDO::PARAM_INT);
            $stmt->bindParam(":alasan", $alasan, PDO::PARAM_STR);
            $stmt->bindParam(":tanggal", $tanggal);
            if ($jam === null) {
                $stmt->bindValue(":jam", null, PDO::PARAM_NULL);
            } else {
                $stmt->bindValue(":jam", $jam, PDO::PARAM_STR);
            }
            $stmt->execute();
            return $this->conn->lastInsertId();
        } catch (PDOException $e) {
            // store last error for diagnostics
            $this->lastError = $e->getMessage();
            return false;
        }
    }

    public function getLastError(){
        return $this->lastError;
    }

    public function getById($id){
        $stmt = $this->conn->prepare("SELECT * FROM izin WHERE id=:id");
        $stmt->bindParam(":id",$id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function updateStatus($id, $status){
        $stmt = $this->conn->prepare("UPDATE izin SET status=:status WHERE id=:id");
        $stmt->bindParam(":status",$status);
        $stmt->bindParam(":id",$id);
        $stmt->execute();
    }

    public function update($id, $alasan, $tanggal, $jam = null){
        try {
            $stmt = $this->conn->prepare("UPDATE izin SET alasan=:alasan, tanggal=:tanggal, jam=:jam WHERE id=:id");
            $stmt->bindParam(":alasan", $alasan, PDO::PARAM_STR);
            $stmt->bindParam(":tanggal", $tanggal);
            if ($jam === null) {
                $stmt->bindValue(":jam", null, PDO::PARAM_NULL);
            } else {
                $stmt->bindValue(":jam", $jam, PDO::PARAM_STR);
            }
            $stmt->bindParam(":id", $id, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (PDOException $e) {
            $this->lastError = $e->getMessage();
            return false;
        }
    }

    public function delete($id){
        $stmt = $this->conn->prepare("DELETE FROM izin WHERE id=:id");
        $stmt->bindParam(":id",$id);
        $stmt->execute();
    }
}
