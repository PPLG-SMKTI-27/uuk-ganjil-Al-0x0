<?php
class User {
    private $conn;
    private $table = "users";

    public function __construct($db){
        $this->conn = $db;
    }

    public function login($username, $password, $role){
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE username=:username AND role=:role");
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":role", $role);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user) return false;

        // Use password_hash / password_verify if available
        if (isset($user['password']) && password_verify($password, $user['password'])) {
            return $user;
        }

        // Fallback for legacy MD5 passwords: if md5 matches, rehash and update DB
        if (isset($user['password']) && md5($password) === $user['password']) {
            $newHash = password_hash($password, PASSWORD_DEFAULT);
            $upd = $this->conn->prepare("UPDATE users SET password=:pw WHERE id=:id");
            $upd->bindParam(":pw", $newHash);
            $upd->bindParam(":id", $user['id']);
            $upd->execute();
            $user['password'] = $newHash;
            return $user;
        }

        return false;
    }

    public function getOrCreate($nama, $role){
        try {
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE nama=:nama AND role=:role");
            $stmt->bindParam(":nama", $nama);
            $stmt->bindParam(":role", $role);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if($user) return $user['id'];

            $username = strtolower(str_replace(' ','',$nama)).rand(10,99);
            $password = md5('12345');
            $stmt = $this->conn->prepare("INSERT INTO users (username, password, role, nama) VALUES (:username, :password, :role, :nama)");
            $stmt->bindParam(":username",$username);
            $stmt->bindParam(":password",$password);
            $stmt->bindParam(":role",$role);
            $stmt->bindParam(":nama",$nama);
            $stmt->execute();
            return $this->conn->lastInsertId();
        } catch (PDOException $e) {
            // Log or handle error in production; return false for caller to handle
            return false;
        }
    }

    public function create($username, $password, $role, $nama = null){
        // check existing username
        try {
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE username=:username");
            $stmt->bindParam(":username", $username);
            $stmt->execute();
            if($stmt->fetch(PDO::FETCH_ASSOC)){
                return false;
            }

            // Hash password securely
            $hash = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $this->conn->prepare("INSERT INTO users (username, password, role, nama) VALUES (:username, :password, :role, :nama)");
            $stmt->bindParam(":username", $username);
            $stmt->bindParam(":password", $hash);
            $stmt->bindParam(":role", $role);
            $stmt->bindParam(":nama", $nama);
            $stmt->execute();
            return $this->conn->lastInsertId();
        } catch (PDOException $e) {
            return false;
        }
    }

    public function getById($id){
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
